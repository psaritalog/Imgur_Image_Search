package com.example.imgursearchtask;

public class Context {
}
