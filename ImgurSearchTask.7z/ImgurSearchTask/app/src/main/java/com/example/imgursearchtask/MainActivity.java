package com.example.imgursearchtask;

import androidx.appcompat.app.AppCompatActivity;

import android.app.SearchManager;
import android.content.ClipData;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.ListAdapter;
import android.widget.Toolbar;

import java.io.File;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {


    public final static String TAG = MainActivity.class.getSimpleName();

    /*
      These annotations are for ButterKnife by Jake Wharton
      https://github.com/JakeWharton/butterknife
     */

    ImageView uploadImage;

    EditText uploadTitle;
    EditText uploadDesc;
    Toolbar toolbar;

    private Upload upload; // Upload object containging image and meta data
    private File chosenFile; //chosen file from intent

    GridView simpleList;
    ArrayList birdList=new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.image_search);
        simpleList = (GridView) findViewById(R.id.simpleGridView);



}
}