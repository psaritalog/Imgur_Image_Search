package com.example.imgursearchtask;

public @interface POST {
}
