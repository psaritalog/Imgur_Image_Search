package com.example.imgursearchtask;

import android.view.View;

import java.util.ArrayList;

public class MyAdapter {
    private static final ArrayList objects = ;

    public MyAdapter(MainActivity mainActivity, int image_view_comment, ArrayList birdList) {

        ArrayList birdList = new ArrayList<>();

    public MyAdapter(Context context, int textViewResourceId, ArrayList objects) {
            super(context, textViewResourceId, objects);
            birdList = objects;
        }

        @Override
        public int getCount() {
            return super.getCount();
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {

            View v = convertView;
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = inflater.inflate(R.layout.grid_view_items, null);
            TextView textView = (TextView) v.findViewById(R.id.textView);
            ImageView imageView = (ImageView) v.findViewById(R.id.imageView);
            textView.setText(birdList.get(position).getbirdName());
            imageView.setImageResource(birdList.get(position).getbirdImage());
            return v;

        }




    }
}
