package com.example.imgursearchtask;

import java.io.File;

public class Upload {
    public File image;
    public String title;
    public String description;
    public String albumId;
}
