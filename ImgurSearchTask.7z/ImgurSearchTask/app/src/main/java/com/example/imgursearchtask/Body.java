package com.example.imgursearchtask;

public @interface Body {
}
