package com.example.imgursearchtask;

public @interface Bind {
}
